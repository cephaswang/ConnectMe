import Foundation
import FirebaseAuth
import SwiftUI
import Combine
import AuthenticationServices
import CryptoKit
import GoogleSignIn

class AuthViewModel: ObservableObject {
    @Published var currentUser: User?
    @Published var isSignedIn = false
    @Published var isLoading = false
    @Published var errorMessage = ""
    private var currentNonce: String?
    
    private let authService = AuthService.shared
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        self.currentUser = authService.getCurrentUser()
        self.isSignedIn = currentUser != nil
        setupAuthListener()
    }
    
    private func setupAuthListener() {
        Auth.auth().addStateDidChangeListener { [weak self] _, user in
            DispatchQueue.main.async {
                self?.currentUser = user
                self?.isSignedIn = user != nil
            }
        }
    }
    
    // MARK: - Email/Password Authentication
    
    func signIn(email: String, password: String) {
        guard !email.isEmpty, !password.isEmpty else {
            errorMessage = "請填寫電子郵件和密碼"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        authService.signIn(email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let user):
                    self?.currentUser = user
                    self?.isSignedIn = true
                    self?.errorMessage = ""
                case .failure(let error):
                    self?.errorMessage = self?.getErrorMessage(from: error) ?? "登入失敗"
                }
            }
        }
    }
    
    func signUp(email: String, password: String) {
        guard !email.isEmpty, !password.isEmpty else {
            errorMessage = "請填寫電子郵件和密碼"
            return
        }
        
        guard password.count >= 6 else {
            errorMessage = "密碼至少需要6個字符"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        authService.signUp(email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let user):
                    self?.currentUser = user
                    self?.isSignedIn = true
                    self?.errorMessage = ""
                case .failure(let error):
                    self?.errorMessage = self?.getErrorMessage(from: error) ?? "註冊失敗"
                }
            }
        }
    }
    
    func signOut() {
        do {
            try authService.signOut()
            DispatchQueue.main.async {
                self.currentUser = nil
                self.isSignedIn = false
                self.errorMessage = ""
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = "登出失敗: \(error.localizedDescription)"
            }
        }
    }
    
    func resetPassword(email: String) {
        guard !email.isEmpty else {
            errorMessage = "請輸入電子郵件地址"
            return
        }
        
        guard isValidEmail(email) else {
            errorMessage = "請輸入有效的電子郵件地址"
            return
        }
        
        authService.resetPassword(email: email) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self?.errorMessage = "密碼重設郵件已發送，請檢查您的郵箱"
                case .failure(let error):
                    self?.errorMessage = self?.getErrorMessage(from: error) ?? "發送重設郵件失敗"
                }
            }
        }
    }
    
    // MARK: - Apple Sign-In
    
    func handleAppleSignIn(credential: ASAuthorizationAppleIDCredential) {
        guard let nonce = currentNonce else {
            DispatchQueue.main.async {
                self.errorMessage = "Apple 登入驗證失敗：無效的安全令牌"
            }
            return
        }
        
        guard let appleIDToken = credential.identityToken,
              let idTokenString = String(data: appleIDToken, encoding: .utf8) else {
            DispatchQueue.main.async {
                self.errorMessage = "Apple 登入失敗：無法獲取身份令牌"
            }
            return
        }
        
        DispatchQueue.main.async {
            self.isLoading = true
            self.errorMessage = ""
        }
        
        let firebaseCredential = OAuthProvider.appleCredential(
            withIDToken: idTokenString,
            rawNonce: nonce,
            fullName: credential.fullName
        )
        
        Auth.auth().signIn(with: firebaseCredential) { [weak self] result, error in
            DispatchQueue.main.async {
                self?.isLoading = false
                if let error = error {
                    self?.errorMessage = "Apple 登入失敗: \(self?.getErrorMessage(from: error) ?? error.localizedDescription)"
                } else if let user = result?.user {
                    self?.currentUser = user
                    self?.isSignedIn = true
                    self?.errorMessage = ""
                    
                    // 如果是新用戶且有姓名信息，更新用戶資料
                    if let fullName = credential.fullName {
                        self?.updateUserProfile(fullName: fullName)
                    }
                }
            }
        }
    }
    
    // MARK: - Google Sign-In (改進版本)
    
    func signInWithGoogle() {
        DispatchQueue.main.async {
            self.isLoading = true
            self.errorMessage = ""
        }
        
        // 檢測是否在模擬器中運行並且設置了模擬模式
        #if targetEnvironment(simulator)
        if ProcessInfo.processInfo.environment["USE_MOCK_GOOGLE_SIGNIN"] == "true" {
            print("🔧 使用模擬 Google 登入模式")
            authService.signInWithGoogleMock { [weak self] result in
                self?.handleGoogleSignInResult(result)
            }
            return
        }
        #endif
        
        authService.signInWithGoogle { [weak self] result in
            self?.handleGoogleSignInResult(result)
        }
    }
    
    private func handleGoogleSignInResult(_ result: Result<User, Error>) {
        DispatchQueue.main.async {
            self.isLoading = false
            switch result {
            case .success(let user):
                self.currentUser = user
                self.isSignedIn = true
                self.errorMessage = ""
                print("✅ Google 登入成功")
            case .failure(let error):
                let errorCode = (error as NSError).code
                
                // 處理特定的錯誤類型
                switch errorCode {
                case -5: // 用戶取消
                    self.errorMessage = "登入已取消"
                case 1100: // AX Lookup 錯誤
                    self.errorMessage = "模擬器權限限制。此錯誤不會影響實際功能，請在真實設備上測試完整功能。"
                    print("🔧 AX Lookup 錯誤 (1100) - 這是 iOS 模擬器的已知問題")
                    print("這個錯誤不會影響應用程式的實際功能")
                default:
                    self.errorMessage = "Google 登入失敗: \(self.getErrorMessage(from: error))"
                }
                
                print("❌ Google 登入失敗: \(error.localizedDescription)")
            }
        }
    }
    
    // 添加重置 Google Sign-In 狀態的方法
    func resetGoogleSignInState() {
        authService.resetGoogleSignInState()
        DispatchQueue.main.async {
            self.errorMessage = ""
        }
    }
    
    // MARK: - Utility Methods
    
    func generateNonce() -> String {
        let nonce = authService.generateNonce()
        currentNonce = nonce
        return nonce
    }
    
    func sha256(_ input: String) -> String {
        return authService.sha256(input)
    }
    
    // MARK: - Private Helper Methods
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    private func updateUserProfile(fullName: PersonNameComponents) {
        guard let user = currentUser else { return }
        
        let displayName = PersonNameComponentsFormatter().string(from: fullName)
        let changeRequest = user.createProfileChangeRequest()
        changeRequest.displayName = displayName
        
        changeRequest.commitChanges { error in
            if let error = error {
                print("更新用戶資料失敗: \(error.localizedDescription)")
            } else {
                print("用戶資料更新成功")
            }
        }
    }
    
    private func getErrorMessage(from error: Error) -> String {
        if let authError = error as NSError? {
            switch AuthErrorCode(rawValue: authError.code) {
            case .emailAlreadyInUse:
                return "此電子郵件地址已被使用"
            case .invalidEmail:
                return "電子郵件地址格式無效"
            case .weakPassword:
                return "密碼強度太弱，請使用至少6個字符"
            case .userNotFound:
                return "找不到此用戶帳號"
            case .wrongPassword:
                return "密碼錯誤"
            case .userDisabled:
                return "此帳號已被停用"
            case .tooManyRequests:
                return "嘗試次數過多，請稍後再試"
            case .networkError:
                return "網路連線錯誤，請檢查網路設定"
            case .invalidCredential:
                return "認證資訊無效"
            default:
                return authError.localizedDescription
            }
        }
        return error.localizedDescription
    }
    
    // MARK: - User State Management
    
    func clearError() {
        errorMessage = ""
    }
    
    func refreshUser() {
        self.currentUser = authService.getCurrentUser()
        self.isSignedIn = currentUser != nil
    }
    
    // MARK: - Validation Helpers
    
    func validateSignUpForm(email: String, password: String, confirmPassword: String) -> String? {
        guard !email.isEmpty else {
            return "請輸入電子郵件地址"
        }
        
        guard isValidEmail(email) else {
            return "請輸入有效的電子郵件地址"
        }
        
        guard !password.isEmpty else {
            return "請輸入密碼"
        }
        
        guard password.count >= 6 else {
            return "密碼至少需要6個字符"
        }
        
        guard password == confirmPassword else {
            return "密碼確認不匹配"
        }
        
        return nil
    }
    
    func validateSignInForm(email: String, password: String) -> String? {
        guard !email.isEmpty else {
            return "請輸入電子郵件地址"
        }
        
        guard isValidEmail(email) else {
            return "請輸入有效的電子郵件地址"
        }
        
        guard !password.isEmpty else {
            return "請輸入密碼"
        }
        
        return nil
    }
}

// MARK: - AuthViewModel Extension for Testing
#if DEBUG
extension AuthViewModel {
    func signInForTesting(email: String, password: String) {
        // 測試用的快速登入方法
        self.currentUser = nil // 模擬用戶
        self.isSignedIn = true
    }
    
    // 切換到模擬 Google 登入模式
    func enableMockGoogleSignIn() {
        setenv("USE_MOCK_GOOGLE_SIGNIN", "true", 1)
        print("🔧 已啟用模擬 Google 登入模式")
    }
    
    // 停用模擬 Google 登入模式
    func disableMockGoogleSignIn() {
        unsetenv("USE_MOCK_GOOGLE_SIGNIN")
        print("🔧 已停用模擬 Google 登入模式")
    }
}
#endif
