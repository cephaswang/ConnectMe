import Foundation
import FirebaseAuth
import SwiftUI
import Combine
import AuthenticationServices
import CryptoKit

class AuthViewModel: ObservableObject {
    @Published var currentUser: User?
    @Published var isSignedIn = false
    @Published var isLoading = false
    @Published var errorMessage = ""
    fileprivate var currentNonce: String?
    
    private let authService = AuthService.shared
    
    init() {
        self.currentUser = authService.getCurrentUser()
        self.isSignedIn = currentUser != nil
        setupAuthListener()
    }
    
    private func setupAuthListener() {
        Auth.auth().addStateDidChangeListener { [weak self] _, user in
            DispatchQueue.main.async {
                self?.currentUser = user
                self?.isSignedIn = user != nil
            }
        }
    }
    
    // MARK: - Authentication Methods
    
    func signIn(email: String, password: String) {
        isLoading = true
        errorMessage = ""
        
        authService.signIn(email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let user):
                    self?.currentUser = user
                    self?.isSignedIn = true
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    func signUp(email: String, password: String) {
        isLoading = true
        errorMessage = ""
        
        authService.signUp(email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let user):
                    self?.currentUser = user
                    self?.isSignedIn = true
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    func signOut() {
        do {
            try authService.signOut()
            self.currentUser = nil
            self.isSignedIn = false
            self.errorMessage = ""
        } catch let signOutError as NSError {
            self.errorMessage = "Error signing out: \(signOutError.localizedDescription)"
        }
    }
    
    func resetPassword(email: String) {
        authService.resetPassword(email: email) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self?.errorMessage = "Password reset email sent successfully"
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    // MARK: - Apple Sign-In
    
    func handleAppleSignIn(credential: ASAuthorizationAppleIDCredential) {
        guard let nonce = currentNonce else {
            errorMessage = "Invalid nonce for Apple Sign-In"
            return
        }
        
        guard let appleIDToken = credential.identityToken,
              let idTokenString = String(data: appleIDToken, encoding: .utf8) else {
            errorMessage = "Unable to fetch Apple ID token"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        // Use the correct Firebase API for Apple Sign-In
        let firebaseCredential = OAuthProvider.appleCredential(withIDToken: idTokenString, rawNonce: nonce, fullName: credential.fullName)
        
        Auth.auth().signIn(with: firebaseCredential) { [weak self] result, error in
            DispatchQueue.main.async {
                self?.isLoading = false
                if let error = error {
                    self?.errorMessage = error.localizedDescription
                } else if let user = result?.user {
                    self?.currentUser = user
                    self?.isSignedIn = true
                }
            }
        }
    }
    
    // Generate a nonce for Apple Sign-In
    func generateNonce() -> String {
        let nonce = authService.generateNonce()
        currentNonce = nonce
        return nonce
    }
    
    // Hash the nonce for Apple Sign-In
    func sha256(_ input: String) -> String {
        return authService.sha256(input)
    }
}
