import SwiftUI
import AuthenticationServices

struct AuthenticationView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var showLogin = true
    @State private var showErrorAlert = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // App Logo or Title
                Text("ConnectMe")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                // Toggle between Login and Register
                Picker("Auth Mode", selection: $showLogin) {
                    Text("登入").tag(true)
                    Text("註冊").tag(false)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                
                // Conditional View
                if showLogin {
                    LoginView()
                } else {
                    RegisterView()
                }
                
                // Divider
                HStack {
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.gray.opacity(0.3))
                    Text("或")
                        .foregroundColor(.gray)
                        .font(.caption)
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.gray.opacity(0.3))
                }
                .padding(.horizontal)
                
                // Social Login Buttons
                VStack(spacing: 12) {
                    // Apple Sign In Button - 修復約束問題
                    SignInWithAppleButton(
                        .signIn,
                        onRequest: { request in
                            let nonce = authViewModel.generateNonce()
                            request.requestedScopes = [.fullName, .email]
                            request.nonce = authViewModel.sha256(nonce)
                        },
                        onCompletion: { result in
                            switch result {
                            case .success(let authResults):
                                if let appleIDCredential = authResults.credential as? ASAuthorizationAppleIDCredential {
                                    authViewModel.handleAppleSignIn(credential: appleIDCredential)
                                }
                            case .failure(let error):
                                authViewModel.errorMessage = error.localizedDescription
                            }
                        }
                    )
                    .signInWithAppleButtonStyle(.black)
                    .frame(maxWidth: .infinity) // 使用 maxWidth 而非固定寬度
                    .frame(height: 44)
                    .cornerRadius(8)
                    .padding(.horizontal) // 增加水平邊距避免約束衝突
                    
                    // Google Sign In Button - 增強錯誤處理
                    Button {
                        authViewModel.signInWithGoogle()
                    } label: {
                        HStack(spacing: 12) {
                            // Google Icon
                            GoogleIconView()
                            
                            Text("使用 Google 登入")
                                .font(.headline)
                                .foregroundColor(.white)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .background(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.red.opacity(0.8), Color.red]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(8)
                        .shadow(color: Color.red.opacity(0.3), radius: 5, x: 0, y: 2)
                    }
                    .disabled(authViewModel.isLoading)
                    
                    // Debug 按鈕 (僅在測試模式下顯示)
                    #if DEBUG
                    VStack(spacing: 8) {
                        Button("🔧 啟用模擬 Google 登入") {
                            authViewModel.enableMockGoogleSignIn()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        
                        Button("🔄 重置 Google 登入狀態") {
                            authViewModel.resetGoogleSignInState()
                        }
                        .font(.caption)
                        .foregroundColor(.orange)
                    }
                    .padding(.top, 8)
                    #endif
                }
                .padding(.horizontal)
                
                // Loading Indicator
                if authViewModel.isLoading {
                    ProgressView("登入中...")
                        .progressViewStyle(CircularProgressViewStyle(tint: .blue))
                }
                
                // Error Message - 增強顯示
                if !authViewModel.errorMessage.isEmpty {
                    VStack(spacing: 8) {
                        Text(authViewModel.errorMessage)
                            .foregroundColor(authViewModel.errorMessage.contains("模擬器") ? .orange : .red)
                            .font(.caption)
                            .padding(.horizontal)
                            .multilineTextAlignment(.center)
                        
                        // 如果是 AX Lookup 錯誤，顯示額外說明
                        if authViewModel.errorMessage.contains("模擬器權限限制") {
                            VStack(spacing: 4) {
                                Text("💡 這是 iOS 模擬器的已知問題")
                                    .font(.caption2)
                                    .foregroundColor(.gray)
                                
                                Text("在真實設備上不會出現此問題")
                                    .font(.caption2)
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal)
                        }
                        
                        // 清除錯誤按鈕
                        Button("清除") {
                            authViewModel.clearError()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                    }
                }
                
                Spacer()
            }
            .padding(.top, 50)
            .navigationBarHidden(true)
            .alert("Google 登入提示", isPresented: $showErrorAlert) {
                Button("確定", role: .cancel) { }
            } message: {
                Text("在模擬器中使用 Google 登入可能會遇到權限問題。這不會影響實際功能，建議在真實設備上測試。")
            }
        }
        .onReceive(authViewModel.$errorMessage) { errorMessage in
            // 當錯誤訊息包含模擬器相關內容時，可以選擇顯示提示
            if errorMessage.contains("1100") || errorMessage.contains("AX Lookup") {
                print("🔧 檢測到 AX Lookup 錯誤，這是模擬器的已知問題")
            }
        }
    }
}

// Google Icon View (保持不變)
struct GoogleIconView: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.white)
                .frame(width: 20, height: 20)
            
            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    Rectangle()
                        .fill(Color.blue)
                        .frame(width: 6, height: 6)
                    Rectangle()
                        .fill(Color.red)
                        .frame(width: 6, height: 6)
                }
                HStack(spacing: 0) {
                    Rectangle()
                        .fill(Color.green)
                        .frame(width: 6, height: 6)
                    Rectangle()
                        .fill(Color.yellow)
                        .frame(width: 6, height: 6)
                }
            }
            .frame(width: 12, height: 12)
        }
    }
}

// Alternative Apple Sign In Button (如果仍有約束問題可以使用)
struct SafeAppleSignInButton: View {
    let onRequest: (ASAuthorizationAppleIDRequest) -> Void
    let onCompletion: (Result<ASAuthorization, Error>) -> Void
    
    var body: some View {
        GeometryReader { geometry in
            SignInWithAppleButton(.signIn, onRequest: onRequest, onCompletion: onCompletion)
                .signInWithAppleButtonStyle(.black)
                .frame(width: min(geometry.size.width - 32, 350), height: 44)
                .position(x: geometry.size.width / 2, y: 22)
        }
        .frame(height: 44)
    }
}

struct AuthenticationView_Previews: PreviewProvider {
    static var previews: some View {
        AuthenticationView()
            .environmentObject(AuthViewModel())
    }
}
