import SwiftUI
import AuthenticationServices

struct AuthenticationView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var showLogin = true
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // App Logo or Title
                Text("ConnectMe")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                // Toggle between Login and Register
                Picker("Auth Mode", selection: $showLogin) {
                    Text("Login").tag(true)
                    Text("Register").tag(false)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                
                // Conditional View
                if showLogin {
                    LoginView()
                } else {
                    RegisterView()
                }
                
                // Apple Sign In Button - Fixed constraints
                SignInWithAppleButton(
                    .signIn,
                    onRequest: { request in
                        let nonce = authViewModel.generateNonce()
                        request.requestedScopes = [.fullName, .email]
                        request.nonce = authViewModel.sha256(nonce)
                    },
                    onCompletion: { result in
                        switch result {
                        case .success(let authResults):
                            if let appleIDCredential = authResults.credential as? ASAuthorizationAppleIDCredential {
                                authViewModel.handleAppleSignIn(credential: appleIDCredential)
                            }
                        case .failure(let error):
                            authViewModel.errorMessage = error.localizedDescription
                        }
                    }
                )
                .signInWithAppleButtonStyle(.black)
                .frame(height: 44) // Only specify height, let width be flexible
                .padding(.horizontal, 20) // Add horizontal padding
                .cornerRadius(8)
                
                // Error Message
                if !authViewModel.errorMessage.isEmpty {
                    Text(authViewModel.errorMessage)
                        .foregroundColor(.red)
                        .font(.caption)
                        .padding(.horizontal)
                        .multilineTextAlignment(.center)
                }
                
                Spacer()
            }
            .padding(.top, 50)
            .navigationBarHidden(true)
        }
    }
}

struct AuthenticationView_Previews: PreviewProvider {
    static var previews: some View {
        AuthenticationView()
            .environmentObject(AuthViewModel())
    }
}
