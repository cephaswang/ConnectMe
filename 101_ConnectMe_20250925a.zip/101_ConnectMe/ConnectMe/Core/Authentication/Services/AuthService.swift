import Foundation
import FirebaseAuth
import FirebaseCore
import AuthenticationServices
import CryptoKit
import GoogleSignIn
import UIKit

class AuthService {
    static let shared = AuthService()
    
    private init() {}
    
    // 檢測是否在模擬器中運行
    private var isSimulator: Bool {
        #if targetEnvironment(simulator)
        return true
        #else
        return false
        #endif
    }
    
    // MARK: - Email/Password Authentication
    
    func signIn(email: String, password: String, completion: @escaping (Result<User, Error>) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(.failure(error))
            } else if let user = result?.user {
                completion(.success(user))
            } else {
                let unknownError = NSError(
                    domain: "AuthService",
                    code: -1,
                    userInfo: [NSLocalizedDescriptionKey: "登入時發生未知錯誤"]
                )
                completion(.failure(unknownError))
            }
        }
    }
    
    func signUp(email: String, password: String, completion: @escaping (Result<User, Error>) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(.failure(error))
            } else if let user = result?.user {
                // 發送驗證郵件（可選）
                user.sendEmailVerification { verificationError in
                    if let verificationError = verificationError {
                        print("發送驗證郵件失敗: \(verificationError.localizedDescription)")
                    }
                }
                completion(.success(user))
            } else {
                let unknownError = NSError(
                    domain: "AuthService",
                    code: -1,
                    userInfo: [NSLocalizedDescriptionKey: "註冊時發生未知錯誤"]
                )
                completion(.failure(unknownError))
            }
        }
    }
    
    func signOut() throws {
        try Auth.auth().signOut()
        GIDSignIn.sharedInstance.signOut()
        print("用戶已成功登出")
    }
    
    func resetPassword(email: String, completion: @escaping (Result<Void, Error>) -> Void) {
        Auth.auth().sendPasswordReset(withEmail: email) { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }
    }
    
    // MARK: - Apple Sign-In
    
    func handleAppleSignIn(credential: ASAuthorizationAppleIDCredential, nonce: String, completion: @escaping (Result<User, Error>) -> Void) {
        guard let appleIDToken = credential.identityToken,
              let idTokenString = String(data: appleIDToken, encoding: .utf8) else {
            let tokenError = NSError(
                domain: "AuthService",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "無法獲取 Apple ID 令牌"]
            )
            completion(.failure(tokenError))
            return
        }
        
        let firebaseCredential = OAuthProvider.appleCredential(
            withIDToken: idTokenString,
            rawNonce: nonce,
            fullName: credential.fullName
        )
        
        Auth.auth().signIn(with: firebaseCredential) { result, error in
            if let error = error {
                completion(.failure(error))
            } else if let user = result?.user {
                print("Apple Sign-In 成功: \(user.uid)")
                completion(.success(user))
            } else {
                let unknownError = NSError(
                    domain: "AuthService",
                    code: -1,
                    userInfo: [NSLocalizedDescriptionKey: "Apple 登入時發生未知錯誤"]
                )
                completion(.failure(unknownError))
            }
        }
    }
    
    // MARK: - Google Sign-In (改進版本)
    
    func signInWithGoogle(completion: @escaping (Result<User, Error>) -> Void) {
        // 在模擬器中顯示警告
        if isSimulator {
            print("⚠️ 警告: 在模擬器中運行 Google Sign-In 可能會遇到 AX Lookup 權限問題")
            print("這是 iOS 模擬器的已知問題，不會影響實際功能")
            print("建議在真實設備上測試 Google Sign-In 功能")
        }
        
        guard let presentingViewController = getRootViewController() else {
            let viewControllerError = NSError(
                domain: "AuthService",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "無法找到呈現視圖控制器"]
            )
            completion(.failure(viewControllerError))
            return
        }
        
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            let clientIDError = NSError(
                domain: "AuthService",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "未找到 Firebase 客戶端 ID"]
            )
            completion(.failure(clientIDError))
            return
        }
        
        // 設置 Google Sign-In 配置
        GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientID)
        
        // 檢查是否有現有的登入會話
        if let currentUser = GIDSignIn.sharedInstance.currentUser {
            print("發現現有的 Google 用戶會話，嘗試刷新...")
            currentUser.refreshTokensIfNeeded { [weak self] user, error in
                if let error = error {
                    print("刷新 Google 令牌失敗: \(error.localizedDescription)")
                    self?.performNewGoogleSignIn(presentingViewController: presentingViewController, completion: completion)
                } else if let user = user {
                    self?.authenticateWithFirebase(googleUser: user, completion: completion)
                } else {
                    self?.performNewGoogleSignIn(presentingViewController: presentingViewController, completion: completion)
                }
            }
        } else {
            performNewGoogleSignIn(presentingViewController: presentingViewController, completion: completion)
        }
    }
    
    private func performNewGoogleSignIn(presentingViewController: UIViewController, completion: @escaping (Result<User, Error>) -> Void) {
        GIDSignIn.sharedInstance.signIn(withPresenting: presentingViewController) { [weak self] result, error in
            if let error = error {
                // 檢查是否是用戶取消操作
                let nsError = error as NSError
                if nsError.code == -5 { // GIDSignInErrorCodeCanceled
                    let cancelError = NSError(
                        domain: "AuthService",
                        code: -5,
                        userInfo: [NSLocalizedDescriptionKey: "用戶取消了 Google 登入"]
                    )
                    completion(.failure(cancelError))
                } else if nsError.code == 1100 { // AX Lookup error
                    print("🔧 檢測到 AX Lookup 錯誤 (1100) - 這是模擬器的已知問題")
                    let axError = NSError(
                        domain: "AuthService",
                        code: 1100,
                        userInfo: [NSLocalizedDescriptionKey: "模擬器權限限制，請在真實設備上測試完整功能"]
                    )
                    completion(.failure(axError))
                } else {
                    print("Google Sign-In 錯誤: \(error.localizedDescription)")
                    completion(.failure(error))
                }
                return
            }
            
            guard let user = result?.user else {
                let noUserError = NSError(
                    domain: "AuthService",
                    code: -1,
                    userInfo: [NSLocalizedDescriptionKey: "無法獲取 Google 用戶信息"]
                )
                completion(.failure(noUserError))
                return
            }
            
            self?.authenticateWithFirebase(googleUser: user, completion: completion)
        }
    }
    
    private func authenticateWithFirebase(googleUser: GIDGoogleUser, completion: @escaping (Result<User, Error>) -> Void) {
        guard let idToken = googleUser.idToken?.tokenString else {
            let tokenError = NSError(
                domain: "AuthService",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "無法獲取 Google ID 令牌"]
            )
            completion(.failure(tokenError))
            return
        }
        
        let accessToken = googleUser.accessToken.tokenString
        let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)
        
        Auth.auth().signIn(with: credential) { result, error in
            if let error = error {
                print("Firebase Google 登入錯誤: \(error.localizedDescription)")
                completion(.failure(error))
            } else if let user = result?.user {
                print("Google Sign-In 成功: \(user.uid)")
                completion(.success(user))
            } else {
                let unknownError = NSError(
                    domain: "AuthService",
                    code: -1,
                    userInfo: [NSLocalizedDescriptionKey: "Google 登入時發生未知錯誤"]
                )
                completion(.failure(unknownError))
            }
        }
    }
    
    // MARK: - Utility Methods
    
    func generateNonce() -> String {
        let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        let nonce = String((0..<32).map { _ in letters.randomElement()! })
        return nonce
    }
    
    func sha256(_ input: String) -> String {
        let inputData = Data(input.utf8)
        let hashedData = SHA256.hash(data: inputData)
        let hashString = hashedData.compactMap {
            String(format: "%02x", $0)
        }.joined()
        return hashString
    }
    
    func getCurrentUser() -> User? {
        return Auth.auth().currentUser
    }
    
    func isUserSignedIn() -> Bool {
        return Auth.auth().currentUser != nil
    }
    
    func getCurrentUserUID() -> String? {
        return Auth.auth().currentUser?.uid
    }
    
    func isEmailVerified() -> Bool {
        return Auth.auth().currentUser?.isEmailVerified ?? false
    }
    
    // MARK: - User Management
    
    func sendEmailVerification(completion: @escaping (Result<Void, Error>) -> Void) {
        guard let user = Auth.auth().currentUser else {
            let noUserError = NSError(
                domain: "AuthService",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "沒有已登入的用戶"]
            )
            completion(.failure(noUserError))
            return
        }
        
        user.sendEmailVerification { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }
    }
    
    func updateUserProfile(displayName: String? = nil, photoURL: URL? = nil, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let user = Auth.auth().currentUser else {
            let noUserError = NSError(
                domain: "AuthService",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "沒有已登入的用戶"]
            )
            completion(.failure(noUserError))
            return
        }
        
        let changeRequest = user.createProfileChangeRequest()
        
        if let displayName = displayName {
            changeRequest.displayName = displayName
        }
        
        if let photoURL = photoURL {
            changeRequest.photoURL = photoURL
        }
        
        changeRequest.commitChanges { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }
    }
    
    func changePassword(newPassword: String, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let user = Auth.auth().currentUser else {
            let noUserError = NSError(
                domain: "AuthService",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "沒有已登入的用戶"]
            )
            completion(.failure(noUserError))
            return
        }
        
        user.updatePassword(to: newPassword) { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }
    }
    
    func deleteAccount(completion: @escaping (Result<Void, Error>) -> Void) {
        guard let user = Auth.auth().currentUser else {
            let noUserError = NSError(
                domain: "AuthService",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "沒有已登入的用戶"]
            )
            completion(.failure(noUserError))
            return
        }
        
        user.delete { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }
    }
    
    // MARK: - Private Helper Methods (改進版本)
    
    private func getRootViewController() -> UIViewController? {
        // 方法 1: 嘗試獲取 key window
        if let windowScene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive }),
           let keyWindow = windowScene.windows.first(where: \.isKeyWindow),
           let rootViewController = keyWindow.rootViewController {
            return getTopViewController(from: rootViewController)
        }
        
        // 方法 2: 備用方案
        if let window = UIApplication.shared.windows.first(where: \.isKeyWindow),
           let rootViewController = window.rootViewController {
            return getTopViewController(from: rootViewController)
        }
        
        // 方法 3: 最後的備用方案
        return UIApplication.shared.windows.first?.rootViewController
    }
    
    private func getTopViewController(from rootViewController: UIViewController) -> UIViewController {
        if let presentedViewController = rootViewController.presentedViewController {
            return getTopViewController(from: presentedViewController)
        }
        
        if let navigationController = rootViewController as? UINavigationController,
           let topViewController = navigationController.topViewController {
            return getTopViewController(from: topViewController)
        }
        
        if let tabBarController = rootViewController as? UITabBarController,
           let selectedViewController = tabBarController.selectedViewController {
            return getTopViewController(from: selectedViewController)
        }
        
        return rootViewController
    }
}

// MARK: - AuthService Extensions

extension AuthService {
    struct UserProfile {
        let uid: String
        let email: String?
        let displayName: String?
        let photoURL: URL?
        let isEmailVerified: Bool
        let creationDate: Date?
        let lastSignInDate: Date?
        
        init(from user: User) {
            self.uid = user.uid
            self.email = user.email
            self.displayName = user.displayName
            self.photoURL = user.photoURL
            self.isEmailVerified = user.isEmailVerified
            self.creationDate = user.metadata.creationDate
            self.lastSignInDate = user.metadata.lastSignInDate
        }
    }
    
    func getCurrentUserProfile() -> UserProfile? {
        guard let user = getCurrentUser() else { return nil }
        return UserProfile(from: user)
    }
    
    // 添加重置 Google Sign-In 狀態的方法
    func resetGoogleSignInState() {
        GIDSignIn.sharedInstance.signOut()
        print("🔄 Google Sign-In 狀態已重置")
    }
}

// MARK: - Debug Support
#if DEBUG
extension AuthService {
    func signInAnonymously(completion: @escaping (Result<User, Error>) -> Void) {
        Auth.auth().signInAnonymously { result, error in
            if let error = error {
                completion(.failure(error))
            } else if let user = result?.user {
                print("匿名登入成功: \(user.uid)")
                completion(.success(user))
            }
        }
    }
    
    func signInWithGoogleMock(completion: @escaping (Result<User, Error>) -> Void) {
        // 創建一個模擬的 Firebase 用戶進行測試
        print("🔧 使用模擬 Google 登入 (僅用於測試)")
        
        // 使用匿名登入來模擬
        Auth.auth().signInAnonymously { result, error in
            if let error = error {
                completion(.failure(error))
            } else if let user = result?.user {
                // 更新用戶資料以模擬 Google 登入
                let changeRequest = user.createProfileChangeRequest()
                changeRequest.displayName = "Test Google User"
                changeRequest.commitChanges { _ in
                    print("模擬 Google 登入成功: \(user.uid)")
                    completion(.success(user))
                }
            }
        }
    }
    
    func printCurrentUserInfo() {
        if let user = getCurrentUser() {
            print("=== 當前用戶資訊 ===")
            print("UID: \(user.uid)")
            print("Email: \(user.email ?? "無")")
            print("顯示名稱: \(user.displayName ?? "無")")
            print("電子郵件已驗證: \(user.isEmailVerified)")
            print("建立日期: \(user.metadata.creationDate?.description ?? "無")")
            print("最後登入: \(user.metadata.lastSignInDate?.description ?? "無")")
            print("==================")
        } else {
            print("沒有已登入的用戶")
        }
    }
}
#endif
