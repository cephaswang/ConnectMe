# Configuration 配置完整指南

## 📋 Configuration 需要處理的項目

### 1. Firebase 配置文件
```
Configuration/
├── GoogleService-Info.plist          // Firebase 專案配置
├── GoogleService-Info-Dev.plist      // 開發環境配置
├── GoogleService-Info-Prod.plist     // 正式環境配置
└── Config.xcconfig                   // 建構時配置
```

### 2. 應用程式配置項目

#### **GoogleService-Info.plist 包含**：
- `API_KEY`: Firebase API 金鑰
- `GCM_SENDER_ID`: 推播服務 ID
- `PLIST_VERSION`: 配置版本
- `BUNDLE_ID`: 應用程式包 ID
- `PROJECT_ID`: Firebase 專案 ID
- `STORAGE_BUCKET`: 儲存桶位址
- `IS_ADS_ENABLED`: 廣告是否啟用
- `IS_ANALYTICS_ENABLED`: 分析是否啟用
- `DATABASE_URL`: 即時資料庫 URL
- `REVERSED_CLIENT_ID`: OAuth 客戶端 ID

#### **Config.xcconfig 包含**：
```config
// 應用程式基本配置
APP_NAME = DatingChatApp
APP_VERSION = 1.0.0
BUILD_VERSION = 1

// 環境配置
DEVELOPMENT_TEAM = YOUR_TEAM_ID
BUNDLE_IDENTIFIER = com.yourcompany.datingchatapp

// Firebase 配置
FIREBASE_PLIST_NAME = GoogleService-Info

// API 配置
BASE_API_URL = https://your-api-domain.com
API_VERSION = v1

// 功能開關
ENABLE_ANALYTICS = YES
ENABLE_CRASHLYTICS = YES
ENABLE_PERFORMANCE_MONITORING = YES

// 第三方服務
APPLE_SIGN_IN_ENABLED = YES
IN_APP_PURCHASE_ENABLED = YES
```

## 🛠️ 完整設定步驟

### 第一階段：Firebase 專案設定

#### 1. 建立 Firebase 專案
```bash
# 前往 Firebase Console
# https://console.firebase.google.com/
```

**操作步驟**：
1. 點擊「建立專案」
2. 輸入專案名稱：`DatingChatApp`
3. 選擇是否啟用 Google Analytics
4. 選擇 Analytics 帳戶（建議啟用）
5. 點擊「建立專案」

#### 2. 新增 iOS 應用程式
1. 點擊 iOS 圖示
2. 輸入 Bundle ID：`com.yourcompany.datingchatapp`
3. 輸入應用程式暱稱：`Dating Chat App`
4. 輸入 App Store ID（可選）
5. 下載 `GoogleService-Info.plist`

#### 3. 啟用 Firebase 服務

**Authentication（認證）**：
1. 前往 Authentication > Sign-in method
2. 啟用「Apple」登入提供者
3. 設定 Apple Developer 團隊設定
4. 啟用「Google」登入提供者（為未來 Android 準備）

**Firestore Database（資料庫）**：
1. 前往 Firestore Database
2. 點擊「建立資料庫」
3. 選擇「以測試模式開始」
4. 選擇資料庫位置（建議選擇亞洲區域）

**Storage（儲存）**：
1. 前往 Storage
2. 點擊「開始使用」
3. 選擇安全規則模式
4. 選擇儲存位置

**Cloud Messaging（推播）**：
1. 前往 Cloud Messaging
2. 系統會自動設定
3. 記下 Server Key（後續需要）

### 第二階段：iOS 專案設定

#### 4. Xcode 專案配置

**添加 GoogleService-Info.plist**：
```swift
// 1. 將下載的 GoogleService-Info.plist 拖拽到 Xcode 專案
// 2. 確保選中 "Add to target"
// 3. 放置在專案根目錄的 Configuration 資料夾中
```

**設定 Info.plist**：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<dict>
    <!-- 基本應用資訊 -->
    <key>CFBundleDisplayName</key>
    <string>交友聊天</string>
    <key>CFBundleIdentifier</key>
    <string>com.yourcompany.datingchatapp</string>
    <key>CFBundleVersion</key>
    <string>1</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0.0</string>
    
    <!-- Apple Sign In 配置 -->
    <key>CFBundleURLTypes</key>
    <array>
        <dict>
            <key>CFBundleURLName</key>
            <string>com.yourcompany.datingchatapp</string>
            <key>CFBundleURLSchemes</key>
            <array>
                <!-- 從 GoogleService-Info.plist 複製 REVERSED_CLIENT_ID -->
                <string>com.googleusercontent.apps.YOUR_REVERSED_CLIENT_ID</string>
            </array>
        </dict>
    </array>
    
    <!-- 權限請求說明 -->
    <key>NSLocationWhenInUseUsageDescription</key>
    <string>此應用需要位置資訊來尋找附近的用戶</string>
    <key>NSCameraUsageDescription</key>
    <string>允許拍照來設定個人檔案照片</string>
    <key>NSPhotoLibraryUsageDescription</key>
    <string>允許選擇照片來設定個人檔案</string>
    <key>NSMicrophoneUsageDescription</key>
    <string>允許錄音來發送語音訊息</string>
    
    <!-- 背景執行模式 -->
    <key>UIBackgroundModes</key>
    <array>
        <string>background-processing</string>
        <string>remote-notification</string>
    </array>
    
    <!-- 支援的裝置方向 -->
    <key>UISupportedInterfaceOrientations</key>
    <array>
        <string>UIInterfaceOrientationPortrait</string>
    </array>
    
    <!-- App Transport Security -->
    <key>NSAppTransportSecurity</key>
    <dict>
        <key>NSAllowsArbitraryLoads</key>
        <false/>
    </dict>
</dict>
```

#### 5. 依賴項目安裝

**Package.swift 或 Podfile 配置**：

**使用 Swift Package Manager**：
```swift
// File > Add Package Dependencies
// 添加以下 URL：

// Firebase
"https://github.com/firebase/firebase-ios-sdk"

// 選擇需要的產品：
// - FirebaseAuth
// - FirebaseFirestore
// - FirebaseStorage
// - FirebaseMessaging
// - FirebaseAnalytics
// - FirebaseCrashlytics
```

**使用 CocoaPods**：
```ruby
# Podfile
platform :ios, '14.0'
use_frameworks!

target 'DatingChatApp' do
  # Firebase
  pod 'Firebase/Auth'
  pod 'Firebase/Firestore'
  pod 'Firebase/Storage'
  pod 'Firebase/Messaging'
  pod 'Firebase/Analytics'
  pod 'Firebase/Crashlytics'
  
  # Additional
  pod 'GoogleSignIn'
end

post_install do |installer|
  installer.pods_project.targets.each do |target|
    target.build_configurations.each do |config|
      config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '14.0'
    end
  end
end
```

### 第三階段：應用程式初始化

#### 6. Firebase 初始化代碼

**DatingChatAppApp.swift**：
```swift
import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseMessaging

@main
struct DatingChatAppApp: App {
    @StateObject private var authViewModel = AuthViewModel()
    
    init() {
        // Firebase 配置
        FirebaseApp.configure()
        
        // 推播通知設定
        configureNotifications()
        
        // 其他初始化設定
        setupAppearance()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(authViewModel)
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                    // 應用程式重新激活時的處理
                    handleAppDidBecomeActive()
                }
        }
    }
    
    private func configureNotifications() {
        UNUserNotificationCenter.current().delegate = NotificationService.shared
        
        let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
        UNUserNotificationCenter.current().requestAuthorization(
            options: authOptions,
            completionHandler: { _, _ in }
        )
        
        UIApplication.shared.registerForRemoteNotifications()
        
        Messaging.messaging().delegate = NotificationService.shared
    }
    
    private func setupAppearance() {
        // 設定全域外觀
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.label
        ]
    }
    
    private func handleAppDidBecomeActive() {
        // 重新檢查認證狀態
        authViewModel.checkAuthenticationState()
    }
}
```

#### 7. Firebase Manager 設定

**FirebaseManager.swift**：
```swift
import Foundation
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage

class FirebaseManager: ObservableObject {
    static let shared = FirebaseManager()
    
    let auth: Auth
    let firestore: Firestore
    let storage: Storage
    
    private init() {
        self.auth = Auth.auth()
        self.firestore = Firestore.firestore()
        self.storage = Storage.storage()
        
        configureFirestore()
    }
    
    private func configureFirestore() {
        let settings = FirestoreSettings()
        settings.isPersistenceEnabled = true
        firestore.settings = settings
    }
}
```

### 第四階段：環境配置

#### 8. 多環境配置

**Config.xcconfig**：
```config
// Development Configuration
#include "Pods/Target Support Files/Pods-DatingChatApp/Pods-DatingChatApp.debug.xcconfig"

// 開發環境
FIREBASE_PLIST_NAME = GoogleService-Info-Dev
API_BASE_URL = https://dev-api.datingchatapp.com
ENABLE_LOGGING = YES

// Release Configuration
#include "Pods/Target Support Files/Pods-DatingChatApp/Pods-DatingChatApp.release.xcconfig"

// 正式環境
FIREBASE_PLIST_NAME = GoogleService-Info-Prod
API_BASE_URL = https://api.datingchatapp.com
ENABLE_LOGGING = NO
```

## ✅ 設定驗證清單

### Firebase 設定檢查
- [ ] Firebase 專案已建立
- [ ] iOS 應用程式已註冊
- [ ] GoogleService-Info.plist 已下載並添加到專案
- [ ] Authentication 提供者已啟用
- [ ] Firestore Database 已建立
- [ ] Storage 已設定
- [ ] Cloud Messaging 已啟用

### iOS 專案檢查
- [ ] Bundle ID 與 Firebase 配置一致
- [ ] Info.plist 權限已設定
- [ ] URL Schemes 已正確配置
- [ ] 依賴項目已安裝
- [ ] Firebase 已在 App.swift 中初始化

### 功能驗證
- [ ] 應用程式可以正常啟動
- [ ] Firebase 連接正常
- [ ] Apple Sign In 可以使用
- [ ] 推播通知權限可以請求
- [ ] 相機和照片庫權限可以請求

## 🔧 除錯常見問題

### 1. GoogleService-Info.plist 找不到
**解決方案**：
- 確保文件已正確添加到 Xcode target
- 檢查文件名稱是否正確
- 確認文件在正確的 bundle 中

### 2. Apple Sign In 無法使用
**解決方案**：
- 檢查 Apple Developer 帳戶的 Sign In with Apple 功能
- 確認 Bundle ID 在 Apple Developer Portal 中已設定
- 檢查 URL Schemes 設定

### 3. 推播通知無法接收
**解決方案**：
- 檢查推播憑證設定
- 確認裝置已註冊推播通知
- 檢查 APNs 設定

### 4. 資料庫連接失敗
**解決方案**：
- 檢查網路連接
- 確認 Firebase 規則設定
- 檢查專案 ID 是否正確

完成以上所有設定步驟後，你的應用程式就具備了完整的 Firebase 整合和基本配置，可以開始開發核心功能了。