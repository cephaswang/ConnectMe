import SwiftUI
import FirebaseAuth

struct ContentView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    
    var body: some View {
        Group {
            if authViewModel.isLoading {
                // Display loading indicator during authentication
                VStack {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .scaleEffect(1.5)
                    Text("Loading...")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding(.top, 10)
                }
            } else if authViewModel.isSignedIn {
                // Main app content for authenticated users
                VStack(spacing: 20) {
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                        .foregroundColor(.blue)
                    
                    Text("Welcome, \(authViewModel.currentUser?.email ?? "User")!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text("You're signed in!")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    Button(action: {
                        authViewModel.signOut()
                    }) {
                        Text("Sign Out")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal, 40)
                    
                    Spacer()
                }
                .padding(.top, 50)
            } else {
                // Authentication view for unauthenticated users
                AuthenticationView()
            }
        }
        .onAppear {
            // Ensure auth state is checked on view appearance
            if let user = authViewModel.currentUser {
                authViewModel.isSignedIn = true
                authViewModel.currentUser = user
            }
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(AuthViewModel())
}
