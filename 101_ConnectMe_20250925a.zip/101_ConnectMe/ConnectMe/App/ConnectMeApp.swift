import SwiftUI
import FirebaseCore
import FirebaseAuth

@main
struct ConnectMeApp: App {
    @StateObject private var authViewModel = AuthViewModel()
    
    init() {
        FirebaseApp.configure()
        print("🔥 Firebase 已配置完成")
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(authViewModel)
        }
    }
}
