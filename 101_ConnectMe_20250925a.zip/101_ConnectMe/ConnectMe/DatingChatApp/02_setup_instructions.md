# Gmail 和 Facebook 登入設置指南

## 1. Firebase 配置

### Google Sign-In 設置
1. 前往 [Firebase Console](https://console.firebase.google.com/)
2. 選擇您的專案
3. 進入 **Authentication** → **Sign-in method**
4. 啟用 **Google** 登入方式
5. 下載更新的 `GoogleService-Info.plist` 並添加到您的 Xcode 專案中
6. 從 `GoogleService-Info.plist` 中找到 `REVERSED_CLIENT_ID` 並更新 Info.plist

## 2. Facebook 應用程式設置

### 創建 Facebook 應用程式
1. 前往 [Facebook for Developers](https://developers.facebook.com/)
2. 創建新的應用程式或使用現有的應用程式
3. 添加 **Facebook Login** 產品
4. 在 **Facebook Login** → **Settings** 中：
   - 添加有效的 OAuth 重定向 URI
   - 設置 Bundle ID

### 獲取 Facebook 配置資訊
1. 從應用程式儀表板複製 **App ID**
2. 從 **Settings** → **Advanced** 複製 **Client Token**
3. 更新 Info.plist 中的以下項目：
   - `YOUR_FACEBOOK_APP_ID` 替換為您的 App ID
   - `YOUR_FACEBOOK_CLIENT_TOKEN` 替換為您的 Client Token

## 3. Firebase Authentication 設置

### 啟用 Facebook 登入
1. 在 Firebase Console 中，前往 **Authentication** → **Sign-in method**
2. 啟用 **Facebook** 登入方式
3. 輸入您的 Facebook App ID 和 App Secret
4. 複製 OAuth 重定向 URI 並添加到 Facebook 應用程式設置中

## 4. Xcode 專案配置

### 添加依賴項
如果使用 Swift Package Manager，添加以下套件：

```
https://github.com/firebase/firebase-ios-sdk
https://github.com/google/GoogleSignIn-iOS
https://github.com/facebook/facebook-ios-sdk
```

### 更新 Info.plist
1. 將 `YOUR_REVERSED_CLIENT_ID` 替換為從 GoogleService-Info.plist 中的實際值
2. 將 `YOUR_FACEBOOK_APP_ID` 替換為您的 Facebook App ID
3. 將 `YOUR_FACEBOOK_CLIENT_TOKEN` 替換為您的 Facebook Client Token

### 示例 GoogleService-Info.plist 查找
在 GoogleService-Info.plist 中找到：
```xml
<key>REVERSED_CLIENT_ID</key>
<string>com.googleusercontent.apps.123456789-abcdefg</string>
```

將此值用於 Info.plist 中的 URL Scheme。

## 5. 測試登入功能

### Google 登入測試
1. 確保設備已安裝 Google 應用程式或使用網頁版登入
2. 測試登入流程
3. 檢查 Firebase Console 中是否顯示新用戶

### Facebook 登入測試
1. 確保設備已安裝 Facebook 應用程式或使用網頁版登入
2. 測試登入流程
3. 檢查 Firebase Console 中是否顯示新用戶

## 6. 故障排除

### 常見問題
- **Google 登入失敗**: 檢查 REVERSED_CLIENT_ID 是否正確設置
- **Facebook 登入失敗**: 檢查 App ID 和 Bundle ID 是否匹配
- **Firebase 錯誤**: 確保 GoogleService-Info.plist 是最新版本

### Debug 提示
- 使用 Xcode 控制台查看詳細錯誤訊息
- 確保所有 URL Schemes 都正確設置
- 檢查網路連接和防火牆設置

## 7. 安全性考慮

### 最佳實踐
- 定期更新所有 SDK 到最新版本
- 使用強密碼原則
- 啟用 Firebase Security Rules
- 實施適當的用戶權限管理

### 隱私設置
- 在應用程式中添加適當的隱私政策連結
- 告知用戶收集哪些資料
- 提供資料刪除選項