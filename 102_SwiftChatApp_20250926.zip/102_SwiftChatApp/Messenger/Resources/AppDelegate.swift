//
//  AppDelegate.swift
//  Messenger
//
//  Created by Afraz Siddiqui on 6/6/20.
//  Copyright © 2020 ASN GROUP LLC. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FBSDKCoreKit
import GoogleSignIn

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    public var signInConfig: GIDConfiguration?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {

        FirebaseApp.configure()
        
        // 添加除錯訊息
        if let app = FirebaseApp.app() {
            print("✅ Firebase 配置成功")
            if let clientId = app.options.clientID {
                print("✅ Google Client ID: \(clientId)")
                signInConfig = GIDConfiguration(clientID: clientId)
            } else {
                print("❌ 無法獲取 Google Client ID")
            }
        } else {
            print("❌ Firebase 配置失敗 - 可能找不到 GoogleService-Info.plist")
        }
        
        ApplicationDelegate.shared.application(
            application,
            didFinishLaunchingWithOptions: launchOptions
        )

        GIDSignIn.sharedInstance.restorePreviousSignIn { [weak self] user, error in
            if let user = user, error == nil {
                print("✅ Restoring previous Google Sign-In session for user: \(user.profile?.email ?? "unknown")")
                self?.handleSessionRestore(user: user)
            } else if let error = error {
                print("❌ Failed to restore previous Google Sign-In session: \(error.localizedDescription)")
            }
        }

        return true
    }

    func application(
        _ app: UIApplication,
        open url: URL,
        options: [UIApplication.OpenURLOptionsKey : Any] = [:]
    ) -> Bool {
        print("Handling URL: \(url)")
        var handled: Bool
        
        // Handle Google Sign-In URL
        handled = GIDSignIn.sharedInstance.handle(url)
        if handled {
            print("✅ Google Sign-In handled URL: \(url)")
            return true
        }
        
        // Handle Facebook Sign-In URL
        handled = ApplicationDelegate.shared.application(app, open: url, options: options)
        if handled {
            print("✅ Facebook Sign-In handled URL: \(url)")
            return true
        }
        
        print("❌ No handler for URL: \(url)")
        return false
    }

    func handleSessionRestore(user: GIDGoogleUser) {
        guard let email = user.profile?.email else {
            print("❌ Failed to get user email")
            return
        }
        
        let firstName = user.profile?.givenName ?? "Unknown"
        let lastName = user.profile?.familyName ?? "Unknown"
        
        print("✅ Processing user - email: \(email), name: \(firstName) \(lastName)")
        UserDefaults.standard.set(email, forKey: "email")
        UserDefaults.standard.set("\(firstName) \(lastName)", forKey: "name")
        print("✅ Saved to UserDefaults - email: \(email), name: \(firstName) \(lastName)")

        DatabaseManager.shared.userExists(with: email, completion: { exists in
            if !exists {
                let chatUser = ChatAppUser(
                    firstName: firstName,
                    lastName: lastName,
                    emailAddress: email
                )
                DatabaseManager.shared.insertUser(with: chatUser, completion: { success in
                    if success {
                        print("✅ Successfully inserted user into database: \(chatUser.emailAddress)")
                        if user.profile?.hasImage == true {
                            guard let url = user.profile?.imageURL(withDimension: 200) else {
                                print("❌ Failed to get profile image URL")
                                return
                            }
                            DispatchQueue.global().async {
                                URLSession.shared.dataTask(with: url) { data, _, _ in
                                    guard let data = data else {
                                        print("❌ Failed to get profile image data from Google")
                                        return
                                    }
                                    let filename = chatUser.profilePictureFileName
                                    StorageManager.shared.uploadProfilePicture(with: data, fileName: filename, completion: { result in
                                        DispatchQueue.main.async {
                                            switch result {
                                            case .success(let downloadUrl):
                                                UserDefaults.standard.set(downloadUrl, forKey: "profile_picture_url")
                                                print("✅ Profile picture uploaded: \(downloadUrl)")
                                            case .failure(let error):
                                                print("❌ Storage manager error: \(error)")
                                            }
                                        }
                                    })
                                }.resume()
                            }
                        }
                    } else {
                        print("❌ Failed to insert user into database")
                    }
                })
            } else {
                print("✅ User already exists in database: \(email)")
            }
        })

        guard let idToken = user.idToken?.tokenString else {
            print("❌ Failed to get ID token")
            return
        }
        
        let accessToken = user.accessToken.tokenString
        let credential = GoogleAuthProvider.credential(
            withIDToken: idToken,
            accessToken: accessToken
        )

        Auth.auth().signIn(with: credential, completion: { authResult, error in
            guard authResult != nil, error == nil else {
                print("❌ Failed to log in with Google credential: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            print("✅ Successfully signed in with Google")
            NotificationCenter.default.post(name: .didLogInNotification, object: nil)
        })
    }
    
    func signOutGoogle() {
        GIDSignIn.sharedInstance.signOut()
        print("✅ User signed out from Google")
    }
}
