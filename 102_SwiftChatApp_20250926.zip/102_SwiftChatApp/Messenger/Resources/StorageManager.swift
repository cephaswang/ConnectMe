//
//  StorageManager.swift
//  Messenger
//
//  Created by Afraz Siddiqui on 6/11/20.
//  Copyright Â© 2020 ASN GROUP LLC. All rights reserved.
//

import Foundation
import FirebaseStorage
import FirebaseAuth

/// Allows you to get, fetch, and upload files to firebase storage
final class StorageManager {

    static let shared = StorageManager()

    private init() {}

    private let storage = Storage.storage().reference()

    public typealias UploadPictureCompletion = (Result<String, Error>) -> Void

    /// Uploads picture to firebase storage and returns completion with url string to download
    public func uploadProfilePicture(with data: Data, fileName: String, completion: @escaping UploadPictureCompletion) {
        print("🔄 Starting profile picture upload...")
        print("📁 File name: \(fileName)")
        print("📊 Data size: \(data.count) bytes")
        
        // Check if user is authenticated
        guard let currentUser = Auth.auth().currentUser else {
            print("❌ No authenticated user found for upload")
            completion(.failure(StorageErrors.failedToUpload))
            return
        }
        
        print("✅ User authenticated: \(currentUser.uid)")
        
        let reference = storage.child("images/\(fileName)")
        print("📍 Upload path: images/\(fileName)")
        
        // Create metadata
        let metadata = StorageMetadata()
        metadata.contentType = "image/png"
        
        reference.putData(data, metadata: metadata) { [weak self] metadata, error in
            guard let strongSelf = self else {
                print("❌ StorageManager was deallocated")
                completion(.failure(StorageErrors.failedToUpload))
                return
            }

            if let error = error {
                print("❌ Upload failed with error: \(error)")
                print("❌ Error code: \(error._code)")
                print("❌ Error domain: \(error._domain)")
                print("❌ Error description: \(error.localizedDescription)")
                completion(.failure(StorageErrors.failedToUpload))
                return
            }

            print("✅ Upload successful, getting download URL...")

            strongSelf.storage.child("images/\(fileName)").downloadURL { url, error in
                if let error = error {
                    print("❌ Failed to get download URL: \(error)")
                    print("❌ Download URL error code: \(error._code)")
                    print("❌ Download URL error domain: \(error._domain)")
                    completion(.failure(StorageErrors.failedToGetDownloadUrl))
                    return
                }
                
                guard let url = url else {
                    print("❌ Download URL is nil")
                    completion(.failure(StorageErrors.failedToGetDownloadUrl))
                    return
                }

                let urlString = url.absoluteString
                print("✅ Download URL obtained: \(urlString)")
                completion(.success(urlString))
            }
        }
    }

    /// Upload image that will be sent in a conversation message
    public func uploadMessagePhoto(with data: Data, fileName: String, completion: @escaping UploadPictureCompletion) {
        print("🔄 Starting message photo upload...")
        print("📁 File name: \(fileName)")
        print("📊 Data size: \(data.count) bytes")
        
        guard Auth.auth().currentUser != nil else {
            print("❌ No authenticated user found for message photo upload")
            completion(.failure(StorageErrors.failedToUpload))
            return
        }
        
        let reference = storage.child("message_images/\(fileName)")
        print("📍 Upload path: message_images/\(fileName)")
        
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"
        
        reference.putData(data, metadata: metadata) { [weak self] metadata, error in
            if let error = error {
                print("❌ Message photo upload failed: \(error.localizedDescription)")
                completion(.failure(StorageErrors.failedToUpload))
                return
            }

            print("✅ Message photo upload successful, getting download URL...")

            self?.storage.child("message_images/\(fileName)").downloadURL { url, error in
                if let error = error {
                    print("❌ Failed to get message photo download URL: \(error.localizedDescription)")
                    completion(.failure(StorageErrors.failedToGetDownloadUrl))
                    return
                }
                
                guard let url = url else {
                    print("❌ Message photo download URL is nil")
                    completion(.failure(StorageErrors.failedToGetDownloadUrl))
                    return
                }

                let urlString = url.absoluteString
                print("✅ Message photo download URL: \(urlString)")
                completion(.success(urlString))
            }
        }
    }

    /// Upload video that will be sent in a conversation message
    public func uploadMessageVideo(with fileUrl: URL, fileName: String, completion: @escaping UploadPictureCompletion) {
        print("🔄 Starting video upload...")
        print("📁 File name: \(fileName)")
        print("📍 File URL: \(fileUrl)")
        
        guard Auth.auth().currentUser != nil else {
            print("❌ No authenticated user found for video upload")
            completion(.failure(StorageErrors.failedToUpload))
            return
        }
        
        let reference = storage.child("message_videos/\(fileName)")
        print("📍 Upload path: message_videos/\(fileName)")
        
        let metadata = StorageMetadata()
        metadata.contentType = "video/mp4"
        
        reference.putFile(from: fileUrl, metadata: metadata) { [weak self] metadata, error in
            if let error = error {
                print("❌ Video upload failed: \(error.localizedDescription)")
                completion(.failure(StorageErrors.failedToUpload))
                return
            }

            print("✅ Video upload successful, getting download URL...")

            self?.storage.child("message_videos/\(fileName)").downloadURL { url, error in
                if let error = error {
                    print("❌ Failed to get video download URL: \(error.localizedDescription)")
                    completion(.failure(StorageErrors.failedToGetDownloadUrl))
                    return
                }
                
                guard let url = url else {
                    print("❌ Video download URL is nil")
                    completion(.failure(StorageErrors.failedToGetDownloadUrl))
                    return
                }

                let urlString = url.absoluteString
                print("✅ Video download URL: \(urlString)")
                completion(.success(urlString))
            }
        }
    }

    public enum StorageErrors: Error {
        case failedToUpload
        case failedToGetDownloadUrl
    }

    public func downloadURL(for path: String, completion: @escaping (Result<URL, Error>) -> Void) {
        let reference = storage.child(path)

        reference.downloadURL { url, error in
            guard let url = url, error == nil else {
                completion(.failure(StorageErrors.failedToGetDownloadUrl))
                return
            }

            completion(.success(url))
        }
    }
}
