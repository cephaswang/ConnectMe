//
//  ProfileViewController.swift
//  Messenger
//
//  Created by Afraz Siddiqui on 6/6/20.
//  Copyright Â© 2020 ASN GROUP LLC. All rights reserved.
//

import UIKit
import FirebaseAuth
import FBSDKLoginKit
import GoogleSignIn
import SDWebImage

final class ProfileViewController: UIViewController {

    @IBOutlet var tableView: UITableView!

    var data = [ProfileViewModel]()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(ProfileTableViewCell.self,
                           forCellReuseIdentifier: ProfileTableViewCell.identifier)

        data.append(ProfileViewModel(viewModelType: .info,
                                     title: "Name: \(UserDefaults.standard.value(forKey:"name") as? String ?? "No Name")",
                                     handler: nil))
        data.append(ProfileViewModel(viewModelType: .info,
                                     title: "Email: \(UserDefaults.standard.value(forKey:"email") as? String ?? "No Email")",
                                     handler: nil))
        data.append(ProfileViewModel(viewModelType: .logout, title: "Log Out", handler: { [weak self] in

            guard let strongSelf = self else {
                return
            }

            let actionSheet = UIAlertController(title: "",
                                          message: "",
                                          preferredStyle: .actionSheet)
            actionSheet.addAction(UIAlertAction(title: "Log Out",
                                          style: .destructive,
                                          handler: { [weak self] _ in

                                            guard let strongSelf = self else {
                                                return
                                            }

                                            UserDefaults.standard.setValue(nil, forKey: "email")
                                            UserDefaults.standard.setValue(nil, forKey: "name")
                                            UserDefaults.standard.setValue(nil, forKey: "profile_picture_url")
                                            UserDefaults.standard.setValue(nil, forKey: "cached_profile_image")

                                            // Log Out facebook
                                            FBSDKLoginKit.LoginManager().logOut()

                                            // Google Log out
                                            GIDSignIn.sharedInstance.signOut()

                                            do {
                                                try FirebaseAuth.Auth.auth().signOut()

                                                let vc = LoginViewController()
                                                let nav = UINavigationController(rootViewController: vc)
                                                nav.modalPresentationStyle = .fullScreen
                                                strongSelf.present(nav, animated: true)
                                            }
                                            catch {
                                                print("Failed to log out")
                                            }

            }))

            actionSheet.addAction(UIAlertAction(title: "Cancel",
                                                style: .cancel,
                                                handler: nil))

            strongSelf.present(actionSheet, animated: true)
        }))

        tableView.register(UITableViewCell.self,
                           forCellReuseIdentifier: "cell")
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableHeaderView = createTableHeader()
    }

    func createTableHeader() -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0,
                                        y: 0,
                                        width: self.view.width,
                                        height: 300))

        headerView.backgroundColor = .link

        let imageView = UIImageView(frame: CGRect(x: (headerView.width-150) / 2,
                                                  y: 75,
                                                  width: 150,
                                                  height: 150))
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .white
        imageView.layer.borderColor = UIColor.white.cgColor
        imageView.layer.borderWidth = 3
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = imageView.width/2
        headerView.addSubview(imageView)

        // Try to load profile picture from multiple sources
        loadProfilePicture(into: imageView)

        return headerView
    }
    
    /// 手動刷新個人頭像，強制從服務器獲取最新版本
    public func refreshProfilePicture() {
        // Clear cached data to force refresh
        UserDefaults.standard.setValue(nil, forKey: "cached_profile_image")
        UserDefaults.standard.setValue(nil, forKey: "profile_picture_url")
        
        // Recreate table header
        tableView.tableHeaderView = createTableHeader()
        
        print("Profile picture refresh triggered")
    }
    
    private func loadProfilePicture(into imageView: UIImageView) {
        // Get current saved URL and image data
        let savedUrl = UserDefaults.standard.value(forKey: "profile_picture_url") as? String
        let savedImageData = UserDefaults.standard.data(forKey: "cached_profile_image")
        
        print("Checking cached profile data - URL: \(savedUrl ?? "none"), Data: \(savedImageData?.count ?? 0) bytes")
        
        // First, try to get the latest URL from Firebase Storage
        guard let email = UserDefaults.standard.value(forKey: "email") as? String else {
            print("No email found, using cached image if available")
            loadCachedImageOrDefault(into: imageView, cachedData: savedImageData)
            return
        }

        let safeEmail = DatabaseManager.safeEmail(emailAddress: email)
        let filename = safeEmail + "_profile_picture.png"
        let path = "images/\(filename)"
        
        print("Fetching latest URL from Firebase Storage for: \(path)")
        
        StorageManager.shared.downloadURL(for: path) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let latestUrl):
                    let latestUrlString = latestUrl.absoluteString
                    print("Latest Firebase URL: \(latestUrlString)")
                    
                    // Compare URLs
                    if savedUrl == latestUrlString {
                        // URL is the same, use cached image if available
                        print("URL unchanged, using cached image")
                        self?.loadCachedImageOrDownload(into: imageView,
                                                       url: latestUrl,
                                                       cachedData: savedImageData)
                    } else {
                        // URL is different, download new image
                        print("URL changed, downloading new image")
                        self?.downloadAndCacheImage(into: imageView,
                                                   url: latestUrl,
                                                   urlString: latestUrlString)
                    }
                    
                case .failure(let error):
                    print("Failed to get latest URL from Firebase: \(error)")
                    // Fallback to cached image if available
                    self?.loadCachedImageOrDefault(into: imageView, cachedData: savedImageData)
                }
            }
        }
    }
    
    private func loadCachedImageOrDownload(into imageView: UIImageView, url: URL, cachedData: Data?) {
        if let cachedData = cachedData, let cachedImage = UIImage(data: cachedData) {
            print("Loading from local cache")
            imageView.image = cachedImage
        } else {
            print("No cached image, downloading from URL")
            downloadAndCacheImage(into: imageView, url: url, urlString: url.absoluteString)
        }
    }
    
    private func downloadAndCacheImage(into imageView: UIImageView, url: URL, urlString: String) {
        print("Downloading image from: \(url)")
        
        imageView.sd_setImage(with: url) { [weak self] image, error, cacheType, url in
            if let error = error {
                print("Failed to download image: \(error)")
                self?.setDefaultProfileImage(into: imageView)
            } else if let image = image {
                print("Successfully downloaded and displayed image")
                
                // Cache the image data and URL
                if let imageData = image.pngData() {
                    UserDefaults.standard.setValue(imageData, forKey: "cached_profile_image")
                    UserDefaults.standard.setValue(urlString, forKey: "profile_picture_url")
                    print("Cached image data (\(imageData.count) bytes) and URL")
                }
            }
        }
    }
    
    private func loadCachedImageOrDefault(into imageView: UIImageView, cachedData: Data?) {
        if let cachedData = cachedData, let cachedImage = UIImage(data: cachedData) {
            print("Using cached image (offline mode)")
            imageView.image = cachedImage
        } else {
            print("No cached image available, using default")
            setDefaultProfileImage(into: imageView)
        }
    }
    
    private func setDefaultProfileImage(into imageView: UIImageView) {
        DispatchQueue.main.async {
            imageView.image = UIImage(systemName: "person.circle.fill")
            imageView.tintColor = .systemGray3
            print("Set default profile image")
        }
    }
}

extension ProfileViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let viewModel = data[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: ProfileTableViewCell.identifier,
                                                 for: indexPath) as! ProfileTableViewCell
        cell.setUp(with: viewModel)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        data[indexPath.row].handler?()
    }
}

class ProfileTableViewCell: UITableViewCell {

    static let identifier = "ProfileTableViewCell"

    public func setUp(with viewModel: ProfileViewModel) {
        self.textLabel?.text = viewModel.title
        switch viewModel.viewModelType {
        case .info:
            textLabel?.textAlignment = .left
            selectionStyle = .none
        case .logout:
            textLabel?.textColor = .red
            textLabel?.textAlignment = .center
        }
    }
}
