// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "Messenger",
    defaultLocalization: "en",
    platforms: [
        .iOS(.v15), // Updated to iOS 15 to satisfy all dependencies
        .macOS(.v10_15) // Added explicit macOS support if needed
    ],
    dependencies: [
        .package(url: "https://github.com/firebase/firebase-ios-sdk.git", from: "10.15.0"),
        .package(url: "https://github.com/facebook/facebook-ios-sdk.git", from: "17.0.0"),
        .package(url: "https://github.com/google/GoogleSignIn-iOS.git", from: "7.0.0"),
        .package(url: "https://github.com/MessageKit/MessageKit.git", from: "4.0.0"),
        .package(url: "https://github.com/nathantannar4/InputBarAccessoryView.git", from: "6.1.0"),
        .package(url: "https://github.com/JonasGessner/JGProgressHUD.git", from: "2.2.0"),
        .package(url: "https://github.com/realm/realm-swift.git", from: "10.40.0"),
        .package(url: "https://github.com/SDWebImage/SDWebImage.git", from: "5.16.0"),
    ],
    targets: [
        .target(
            name: "Messenger",
            dependencies: [
                .product(name: "FirebaseAuth", package: "firebase-ios-sdk"),
                .product(name: "FirebaseDatabase", package: "firebase-ios-sdk"),
                .product(name: "FirebaseStorage", package: "firebase-ios-sdk"),
                .product(name: "FirebaseAnalytics", package: "firebase-ios-sdk"),
                .product(name: "FirebaseCrashlytics", package: "firebase-ios-sdk"),
                .product(name: "FacebookLogin", package: "facebook-ios-sdk"),
                .product(name: "GoogleSignIn", package: "GoogleSignIn-iOS"),
                .product(name: "MessageKit", package: "MessageKit"),
                .product(name: "InputBarAccessoryView", package: "InputBarAccessoryView"),
                .product(name: "JGProgressHUD", package: "JGProgressHUD"),
                .product(name: "RealmSwift", package: "realm-swift"),
                .product(name: "SDWebImage", package: "SDWebImage"),
            ],
            path: "Messenger",
            resources: [.process("Resources")]
        )
    ]
)
