https://www.youtube.com/watch?v=Mroju8T7Gdo&list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf
Building Chat App in Swift 5 (Series) Trailer - Introduction 2023



如果你想通过命令行验证 SPM 依赖，可以使用 Swift 工具：
swift package resolve

确保依赖正确解析后，使用以下命令构建项目：
xcodebuild -project Messenger.xcodeproj -scheme Messenger -sdk iphonesimulator

rm -rf .build
rm Package.resolved

swift package reset
swift package resolve
swift build

