https://www.youtube.com/watch?v=Mroju8T7Gdo&list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf
Building Chat App in Swift 5 (Series) Trailer - Introduction 2023



如果你想通过命令行验证 SPM 依赖，可以使用 Swift 工具：
swift package resolve

确保依赖正确解析后，使用以下命令构建项目：
xcodebuild -project Messenger.xcodeproj -scheme Messenger -sdk iphonesimulator

rm -rf .build
rm Package.resolved

swift package reset
swift package resolve
swift build

command shife O 查找檔案


好，方便約時間視訊，我想成功開機。登入的帳號，密碼。

Re-Indent（重新縮排）：Ctrl + I
Format Code（格式化程式碼）：Shift + Option + Command + F


kk

